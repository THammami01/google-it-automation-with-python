# Working w/ Remotes

I am editing the README file. Adding some more details about the project description.
