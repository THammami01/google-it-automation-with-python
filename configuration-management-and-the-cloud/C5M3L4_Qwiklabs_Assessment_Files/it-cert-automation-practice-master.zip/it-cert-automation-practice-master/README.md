# Google IT Automation with Python Professional Certificate - Practice files

This repository contains the practice files used throughout the courses that are
part of the Google IT Automation with Python Professional Certificate

There's a separate folder for each course.

